<template>
	<div>
		<v-container>
			<h1>Sale</h1>
		</v-container>
	</div>
</template>

<script>
export default {

}
</script>

<style>
	
</style>