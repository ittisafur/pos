<template>
	<div>
		<v-container>
			<h1>Category</h1>
		</v-container>
	</div>
</template>

<script>
export default {

}
</script>

<style>
	
</style>